// SUBMISSION NOTE (v18x, 2026-10-18 13:42 UTC)
// Weak-map fixes #16-#18: central altars no longer avoided on stale sightings; opponent model no longer turtles on middle-contest; small banks + working contested-altar logic on collision; monolith bag convoy.
// END NOTE
// Dispatch draft and gameplay; a failed turn is logged and still yields.
#include <cambc.h>
#include <iostream>
#include "bot.h"
#include "draft.h"

int main() {
    Bot bot;
    while (true) {
        try {
            if (cambc::is_draft())
                play_draft();
            else
                bot.play_turn();
        } catch (const std::exception& error) {
            std::cout << "bot error: " << error.what() << std::endl;
        } catch (...) {
            std::cout << "bot error: unknown exception" << std::endl;
        }

        cambc::end_turn();
    }
}
